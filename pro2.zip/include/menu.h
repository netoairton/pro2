#ifndef MENU_H
#define MENU_H

#include <iostream>
//#include "listagem.h"

void menu(int d, int m, int a);

#endif